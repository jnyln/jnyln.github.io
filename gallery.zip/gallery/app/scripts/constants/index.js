export const IMAGE_DIR = `${window.location.origin}${window.location.pathname}app/images/`;

// Determined by react-hammerjs library
export const SWIPE_LEFT = 2;
export const SWIPE_RIGHT = 4;
