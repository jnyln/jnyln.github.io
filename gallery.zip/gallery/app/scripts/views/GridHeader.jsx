import React from 'react';

const GridHeader = () => {
    return (
        <div className="grid_header">
            <h1 className="grid_header__text">Image Gallery</h1>
        </div>
    );
};

export default GridHeader;
